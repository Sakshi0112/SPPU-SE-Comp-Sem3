#include <iostream>
#include<cstring>
using namespace std;

class sll
{
	public:
	struct node
	{
		int prn;
		char name[30];
		struct node *next;
	}*head,*head1;

		sll()
		{
			head=NULL;
			head1=NULL;
		}

 struct node* create()
 {
 	node *p,*q;
 	int i,n;
 	cout<<"\nEnter the total number of members in the club:";
 	cin>>n;
 	for(i=0;i<n;i++)
 	{
 		p=new node;
 		cout<<"\nEnter the name of the member:";
 		cin>>p->name;
 		cout<<"\nEnter the prn of the member:";
 		cin>>p->prn;
 		
 		if(head==NULL)
 		{
 			head=p;
 			p->next=NULL;
 		}
 		else
 		{
 			q=head;
 			while(q->next!=NULL)
 			{
 				q=q->next;
 			}
 			q->next=p;
 			p->next=NULL;
 		}
     }
 		return(head);
 }
 
 struct node *insert_president()
 {
 	node *p,*q;
 	int x;
 	char s[30];
 	p=new node;
 	cout<<"\nEnter the name of the president:";
 	cin>>s;
 	cout<<"\nEnter the prn of the president:";
 	cin>>x;
 	strcpy(p->name,s);
 	p->prn=x;
 	p->next=NULL;
 	if(head==NULL)
 	{
 		head=p;
 		p->next=NULL;
 	}
 	else
 	{
 		p->next=head;
 		head=p;
 	}
   	return(head);
 }
 
 struct node* insert_member()
 {
 	int z,loc;
 	char b[30];
 	node *p,*q;
 	p=new node;
 	cout<<"\nEnter the prn of the member after which you want to insert the member:";
 	cin>>loc;
 	cout<<"\nEnter the name of the member:";
 	cin>>b;
 	cout<<"\nEnter the prn of the member:";
 	cin>>z;
 	p->prn=z;
 	strcpy(p->name,b);
 	if(head==NULL)
 	{
 		head=p;
 		p->next=NULL;
 	}
 	else
 	{
 		q=head;
 		while(q->next!=NULL && q->prn!=loc)
 		{
 			q=q->next;
 		}
 		if(q->prn==loc)
 		{
 			p->next=q->next;
 			q->next=p;
 		}
 		return(head);
 	}
 }
 
 struct node* insert_secretary()
 {
 	int y;
 	char a[30];
 	node *p,*q;
 	p=new node;
 	cout<<"\nEnter the name of the secretary:";
 	cin>>a;
 	cout<<"\nEnter the prn of the secretary:";
 	cin>>y;
 	p->prn=y;
 	strcpy(p->name,a);
 	if(head==NULL)
 	{
 		head=p;
 		p->next=NULL;
 	}
 	else
 	{
 	  q=head;
 	   while(q->next!=NULL)
    	{
 		  q=q->next;
 	    }
 	   q->next=p;
 	    p->next=NULL;
    }
 	return(head);
 }
 struct node *reverse()
 {
 	node *p,*q,*r;
 	p=NULL;
 	q=head;
 	r=q->next;
 	while(q!=NULL)
 	{
 		q->next=p;
 		p=q;
 		q=r;
 		if(r!=NULL)
 		{
 			r=r->next;
 		}
 	}
 	head=p;
  	return(p);
 }
 
 struct node* delete_president()
 {
 	node *p;
 	if(head==NULL)
 	{
 		p=head;
 		head->next=NULL;
 	}
 	else
 	{
 		p=head;
 		head=head->next;
 		delete(p);
 	}
 	return(head);
 }
 
 struct node* delete_member()
 {
 	node *p,*q;
 	int loc;
 	cout<<"\nEnter the prn of the member you want to delete:";
 	cin>>loc;
 	 q=head;
 		while(q->next!=NULL && (q->next)->prn!=loc)
 		{
 			q=q->next;
 		}
 		if((q->next)->prn==loc)
 		{
 		  p=q->next;
 		  q->next=p->next;
 		  delete(p);
     	}
        return(head);
 	
 }
 
 struct node* delete_secretary()
 {
 	node *p,*q;
 	if(head->next==NULL)
 	{
 		delete(head);
 		head=NULL;
 	}
 	else
 	{
 		q=head;
 		while(q->next->next!=NULL)
 		{
 			q=q->next;
 		}
 		q->next=p;
 		delete(p);
 		q->next=NULL;
 	}
 	return(head);
 }
 
 struct node* concatenate(struct node *head)
 {
 	node *p,*q,*r;
 	int i,n;
 	cout<<"\nEnter the total number of members in the club:";
 	cin>>n;
 	for(i=0;i<n;i++)
 	{
 		p=new node;
 		cout<<"\nEnter the name of the member:";
 		cin>>p->name;
 		cout<<"\nEnter the prn of the member:";
 		cin>>p->prn;
 		
 		if(head1==NULL)
 		{
 			head1=p;
 			p->next=NULL;
 		}
 		else
 		{
 			q=head1;
 			while(q->next!=NULL)
 			{
 				q=q->next;
 			}
 			q->next=p;
 			p->next=NULL;
 		}
     }
 	if(head==NULL)
 	{
 		return(head1);
 	}
 	if(head1==NULL)
 	{
 		return(head);
 	}
 	while(r->next!=NULL)
 	{
 		r=r->next;
 	}
 	r->next=head1;
 	return(head);
 }
 
 void count()
 {	int i;
 	node *q;
 	q=head;
 	i=0;
 	while(q->next!=NULL)
 	{
 		q=q->next;
 		i=i+1;
 	}
 	cout<<"\nPinnacle club has total "<<i+1<<" members";
 }
 
 void display()
 {
 	node *q;
 	q=head;
 	while(q!=NULL)
 	{
 		cout<<"NAME:"<<q->name<<"\t";
 		cout<<"PRN:"<<q->prn<<"\n";
 		q=q->next;
 	}
 }
};

int main()
{
	int ch;
	struct node *head;
	sll s;
	do
	{
		cout<<"\nMENU:\n 1.CREATE\t 2.INSERT PRESIDENT\t 3.INSERT MEMBER\t 4.INSERT SECRETARY\t 5.DELETE PRESIDENT\t 6.DELETE MEMBER\t 7.DELETE SECRETARY\t 8.REVERSE\t 9.CONCATENATE\t 10.DISPLAY\t 11.COUNT\t 12.EXIT";
    	cout<<"\nEnter the choice:";
		cin>>ch;
		switch(ch)
		{
			case 1 : s.create();
			         break;
			         
		    case 2 : s.insert_president();
		             break;
		             
		    case 3 : s.insert_member();
		             break;
		             
		    case 4 : s.insert_secretary();
		             break;
		             
		    case 5 : s.delete_president();
		             break;
		             
		    case 6 : s.delete_member();
		             break;
		             
		    case 7 : s.delete_secretary();
		             break;
		             
		    case 8 : s.reverse();
		             break;
		             
		    case 9 : s.concatenate(head);
		             break;
		            
		    case 10 : s.display();
		              break;
		              
		    case 11 : s.count();
		              break;
		              
		    case 12 : break;
		}
	}while(ch!=12);
	return 0;
}
