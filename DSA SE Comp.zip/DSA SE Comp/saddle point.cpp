#include<iostream>
using namespace std;

class saddle
{
	public:
		int a[10][10],i,j,m,n,rowvalue,rowloc,colvalue,colloc;
		void getdata();
		void display();
		int saddle_point();
};

void saddle::getdata()
{
	cout<<"\nEnter the total number of rows and column of the matrix";
	cin>>m>>n;
	cout<<"Enter the elements of the matrix";
	for(i=0;i<m;i++)
	{
		for(j=0;j<n;j++)
		{
			cin>>a[i][j];
		}
	}
}

void saddle::display()
{
	cout<<"\nThe entered matrix is:";
	for(i=0;i<m;i++)
	{
		cout<<"\n";
		for(j=0;j<n;j++)
		{
			cout<<"\t"<<a[i][j];
		}
	}
}

int saddle::saddle_point()
{
  for(i=0;i<m;i++)
  {
  	rowvalue=a[i][0];
  	rowloc=0;
  	for(j=1;j<n;j++)
  	{
  		if(rowvalue>a[i][j])
  		{
  			rowvalue=a[i][j];
  			rowloc=j;
 		}
  	}
  	colvalue=a[0][rowloc];
  	colloc=0;
  	for(j=1;j<m;j++)
  	{
  		if(colvalue<a[j][rowloc])
  		{
  			colvalue=a[j][rowloc];
  			colloc=j;
  		}
  	}
  if(i==colloc)
  {
  	cout<<"\nThe saddle point is present at location:"<<i<<rowloc;
  	return 0;
  }
 }
  if(i!=colloc)
  {
  	cout<<"\nThe saddle point is absent";
  	return 0;
  }
}
int main()
{
	saddle s;
	s.getdata();
	s.display();
	s.saddle_point();
	return 0;
}
