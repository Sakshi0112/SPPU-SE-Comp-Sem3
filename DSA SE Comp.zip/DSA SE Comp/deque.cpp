#include<iostream>
using namespace std;

class deque
{
	public:
		struct queue
		{
			int data[10];
			int r,f;
		}p;
		bool empty();
		bool full();
		void enqueueR();
		void enqueueF();
		void dequeueF();
		void dequeueR();
		void display();
		deque()
		{
			p.r=-1;
			p.f=-1;
		}
};

bool deque::empty()
{
	if(p.r==-1)
	{
		return 1;
	}
	return 0;
}

bool deque::full()
{
	if(p.r==9)
	{
		return 1;
	}
	return 0;
}

void deque::enqueueR()
{   
    int x;
    cout<<"\nEnter the data of the queue:";
    cin>>x;
	if(p.r==9)
	{
		cout<<"\nQueue is full";
	}
	else
	{
		if(p.r==-1)
		{
			p.r=0;
			p.f=0;
			p.data[p.r]=x;
		}
		else
		{
		  p.r=(p.r+1)%10;
	      p.data[p.r]=x;
	    } 
	}
}


void deque::enqueueF()
{
	int x;
    cout<<"\nEnter the data of the queue:";
    cin>>x;
	if(p.r==9)
	{
		cout<<"\nQueue is full";
	}
	else
	{
		if(p.f==-1)
		{
			p.f=0;
			p.r=0;
			p.data[p.f]=x;
		}
		else
		{
		  p.f=(p.f+9)%10;
	      p.data[p.f]=x;
	    } 
	}
	
}

void deque::dequeueF()
{
	int x;
	if(p.r==-1)
	{
	  cout<<"\nQueue is empty";	
	}
	else
	{
		x=p.data[p.f];
		if(p.f==0)
		{
			p.r=-1;
			p.f=-1;
			cout<<"\nThe deleted data is:"<<x;
		}
		else
		{
			x=p.data[p.f];
			p.f=(p.f+1)%10;
			cout<<"\nThe deleted data is:"<<x;
		}
	}
}

void deque::dequeueR()
{
	int x;
	if(p.r==-1)
	{
	  cout<<"\nQueue is empty";	
	}
	else
	{
		x=p.data[p.r];
		if(p.f==0)
		{
			p.r=-1;
			p.f=-1;
			cout<<"\nThe deleted data is:"<<x;
		}
		else
		{
			x=p.data[p.r];
			p.r=(p.r+9)%10;
			cout<<"\nThe deleted data is:"<<x;
		}
	}
}

void deque::display()
{
	int i;
	if(!empty())
   {
   	i=p.f;
	while(i!=p.r)
	{
		cout<<"\t"<<p.data[i];
		i=(i+1)%10;
	}
	cout<<"\t"<<p.data[i];
   }
   else
   {
   	cout<<"\nQueue is empty";
   }
}

int main()
{
	deque d;
	int ch;
	do
	{
		cout<<"\nMENU:\n1.INSERT REAR\t 2.INSERT FRONT\t 3.DELETE FRONT\t 4.DELETE REAR\t 5.DISPLAY\t 6.EXIT";
		cout<<"\nEnter the choice:";
		cin>>ch;
		switch(ch)
		{
			case 1 : d.enqueueR();
			         break;
			         
		    case 2 : d.enqueueF();
		             break;
		             
		    case 3 : d.dequeueF();
		             break;
		             
		    case 4 : d.dequeueR();
		             break;
		             
		    case 5 : d.display();
		             break;
		             
		    case 6 : break;
		}
	}while(ch!=6);
	return 0;
}
