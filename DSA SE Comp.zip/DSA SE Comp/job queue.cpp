#include<iostream>
using namespace std;

class queue
{
	public:
	struct q
	{
		int data[10];
		int r,f;
	}p;
		bool empty();
		bool full();
		void enqueue();
		void dequeue();
		void display();
		queue()
		{
			p.r=-1;
			p.f=-1;
		}
};

bool queue::empty()
{
	if(p.r==-1)
	{
		return 1;
	}
	return 0;
}

bool queue::full()
{
	if(p.r==9)
	{
		return 1;
	}
	return 0;
}

void queue::enqueue()
{
	int x;
	cout<<"\nEnter the value of the job:";
	cin>>x;
	if(p.r==9)
	{
		cout<<"\nQueue is full";
	}
	else
	  if(p.r==-1)
	  {
	  	p.r=0;
	  	p.f=0;
	  	p.data[p.r]=x;
	  }
	  else
	  {
	  	p.r=p.r+1;
	  	p.data[p.r]=x;
	  }
}

void queue::dequeue()
{
	int x;
	if(p.r==-1)
	{
		cout<<"\nQueue is empty";
	}
	else
	  if(p.r==0)
	  {
	  	int x=p.data[p.f];
	  	p.r=-1;
	  	p.f=-1;
	  	cout<<"\nThe job deleted is:"<<x;
	  }
	  else
	  {
	  	int x=p.data[p.f];
	  	p.f=p.f+1;
	  	cout<<"\nThe job deleted is:"<<x;
      }
      
}

void queue::display()
{
	if(!empty())
	{
	   for(int i=p.f;i<=p.r;i++)	
		{
			cout<<"\t"<<p.data[i];
		}
	}
}
	  
int main()
{
  queue q;
  int ch;
  do
  {
  	cout<<"\nMENU: \n 1.INSERT JOB\t 2.DELETE JOB\t 3.DISPLAY THE JOB QUEUE\t 4.EXIT";
  	cout<<"\nEnter the choice:";
  	cin>>ch;
  	switch(ch)
  	{
  		case 1 : q.enqueue();
				 break;
				
		case 2 : q.dequeue();
		         break;
		         
	    case 3 : q.display();
		         break;
		         
		case 4 : break;
  	}
  }while(ch!=4);
  return 0;
}

