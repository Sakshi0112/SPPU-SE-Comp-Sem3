#include<iostream>
using namespace std;

class sort
{
	public:
	float per[30];
    int l,u;
    void quick_sort(float per[30],int l,int u);
    int partition(float per[30],int l,int u);
};
  
int sort::partition(float per[30],int l,int u)
  {
	int i,j;
	float v, temp;
	v=per[l];
	i=l;
	j=u+1;
	do
	{
		do
		{
			i++;
		}while(per[i]<v && i<=u);
		do
		{
			j--;
		}while(per[j]>v);
		if(i<j)
		{
			temp=per[i];
			per[i]=per[j];
			per[j]=temp;
		}
	}while(i<j);
	
	per[l]=per[j];
	per[j]=v;
	cout<<"\nPartition Point:"<<j;
	cout<<"\nList:";
	for(i=l;i<=u;i++)
	{
		cout<<"\t"<<per[i];
	}
	return j;
}

void sort::quick_sort(float per[30],int l,int u)
{
	int j,n;
	n=u+1;
	if(l<u)
	{
	  j=partition(per,l,u);
	  quick_sort(per,l,j-1);
	  quick_sort(per,j+1,u);
    }
}

int main()
{
	sort s;
	int ch,n,i;
	float per[30];
	cout<<"\nEnter the total number of students in the class:";
	cin>>n;
	cout<<"\nEnter the percentage of the students:";
	for(i=0;i<n;i++)
	{
		cin>>per[i];
	}
	do
	{
		cout<<"\nMENU:\n 1.QUICK SORT\t 2.EXIT";
		cout<<"\nEnter the choice:";
		cin>>ch;
		switch(ch)
		{
			case 1 : s.quick_sort(per,0,n-1);
			         cout<<"\nThe top five score is:";
			         for(i=n-1;i>=n-5;i--)
			         {
			         	cout<<"\t"<<per[i];
			         }
			         break;
			
			case 2 : break;
		}
	}while(ch!=2);
	return 0;
}
