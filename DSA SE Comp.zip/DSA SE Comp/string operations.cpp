#include<iostream>
using namespace std;

class strings
{
	public:
	int i,j;
	char s1[10],s2[10];
	public:
		void length();
		void copy();
		void concate();
		void equal();
		void reverse();
		void substring();
};

void strings::length()
{
	cout<<"\nEnter the string1:";
	cin>>s1;
	i=0;
	while(s1[i]!='\0')
	{
		i++;
	}
	cout<<"\nThe total length of the string is:"<<i;
}

void strings::copy()
{
	cout<<"\nEnter the string1:";
	cin>>s1;
	i=0;
	while(s1[i]!='\0')
	{
		s2[i]=s1[i];
		i++;
	}
	s2[i]='\0';
	cout<<"\nThe string1 is:"<<s1;
	cout<<"\nThe copied string2 is:"<<s2;	
}

void strings::concate()
{
	cout<<"\nEnter the string1:";
	cin>>s1;
	cout<<"\nEnter the string2:";
	cin>>s2;
	i=0;
	while(s1[i]!='\0')
	{
		i++;
	}
	j=0;
	while(s2[j]!='\0')
	{
		s1[i]=s2[j];
		i++;
		j++;
	}
	s1[i]=='\0';
	cout<<"\nThe concatenated string is:"<<s1;
}

void strings::equal()
{
	cout<<"\nEnter the string1:";
	cin>>s1;
	cout<<"\nEnter the string2:";
	cin>>s2;
	while(s1[i]==s2[j] && s1[i]!='\0' && s2[j]!='\0')
	{
		i++;
		j++;
	}
	if(s1[i]<s2[j])
	{
		cout<<"s1<s2";
	}
	else
	 if(s1[i]>s2[j])
	 {
	 	cout<<"s1>s2";
	 }
	 else
	 cout<<"s1=s2";
}

void strings::reverse()
{
	char temp;
	cout<<"\nEnter the string1:";
	cin>>s1;
	 i=0;
	 while(s1[i]!='\0')
	 {
	 	i++;
	 }
	 j=i-1;
	 i=0;
	 while(i<j)
	 {
	 	temp=s1[i];
	 	s1[i]=s1[j];
	 	s1[j]=temp;
	 	i++;
	 	j--;
	 }
	 cout<<"\nthe reversed string is:"<<s1;
}

void strings::substring()
{
	 int k;
	cout<<"\nEnter the string1:";
	cin>>s1;
	cout<<"\nEnter the string2:";
	cin>>s2;
	while(s1[i]!=s2[j] && s1[i]!='\0' && s2[j]!='\0')
	{
		i++;
	
	}
	k=i;
	if(s1[i]=='\0')
	{
		cout<<"\nSubstring not present";
	}
	else
	if(s1[i]==s2[j])
	{
		cout<<"\nSubstring present at location:"<<k+1;
	}
	else
	{
		cout<<"\nSubstring not present";
	}
}

int main()
{
	strings s;

	//s.length();
	//s.copy();
	//s.concate();
	//s.reverse();
	//s.equal();
		s.substring();
	return 0;
}
