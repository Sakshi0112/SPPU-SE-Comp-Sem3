#include<iostream>
using namespace std;

class search
{
	public:
		int i,j,n,key,roll_no[30];
		void getdata();
		void sequential_search();
		void sentinel_search();
		void bubble_sort();
		void binary_search();
};

void search::getdata()
{
	cout<<"\nEnter the total number of students who attended the training program:";
	cin>>n;
	cout<<"\nEnter the roll number of students who attended the training program:";
	for(i=0;i<n;i++)
	{
		cin>>roll_no[i];
	}
}
void search::sequential_search()
{
  cout<<"\nEnter the roll number of the student to be searched:";	
  cin>>key;
  i=0;
  while(i<n && roll_no[i]!=key)
  {
  	i++;
  }
  if(i<n)
  {
  	cout<<"\nThe student attended the training program and the roll number is found at location:"<<i+1;
  }
  else
  {
  	cout<<"\nThe student did not attend the training program";
  }
}

void search::sentinel_search()
{
	cout<<"\nEnter the roll number of the student to be searched:";	
    cin>>key;
    roll_no[n]=key;
    i=0;
    while(key!=roll_no[i])
    {
    	i++;
    }
 	if(key==roll_no[i] && i<n)
 	{
 		cout<<"\nThe student attended the training program and the roll number is found at location:"<<i+1;
 	}
 	else
 	{
 		cout<<"\nThe student did not attend the training program";
 	}
}

void search::bubble_sort()
{
	int temp;
	for(i=1;i<n;i++)
	{
		for(j=0;j<n-1;j++)
		{
			if(roll_no[j]>roll_no[j+1])
			{
			  temp=roll_no[j];
			  roll_no[j]=roll_no[j+1];
			  roll_no[j+1]=temp;
            }
		}
	}
	for(i=0;i<n;i++)
	{
		cout<<"\t"<<roll_no[i];
	}
}

void search::binary_search()
{
	cout<<"\nEnter the roll number of student you want to search:";
	cin>>key;
	i=0;
	j=n-1;
	int c=(i+j)/2;
	while(roll_no[c]!=key && i<=j)
	{
		if(key>roll_no[c])
		{
			
			i=c+1;
		}
		else
		{
		
			j=c-1;
		}
		c=(i+j)/2;
	}
	if(i<=j)
	{
		cout<<"\nThe student attended the training program and the roll number was found at location:"<<c+1;
	}
	else
	{
		cout<<"\nThe student did not attend the training program";
	}
}
int main()
{
	int ch;
	search s;
	s.getdata();
	do
	{
		cout<<"\nMENU: \n 1.SEQUENTIAL SEARCH\t 2.SENTINEL SEARCH\t 3.BINARY SEARCH\t 4.EXIT";
		cout<<"\nEnter the choice";
		cin>>ch;
		switch(ch)
		{
			case 1 : s.sequential_search();
			         break;
			        
			case 2 : s.sentinel_search();
			         break;

            case 3 : s.bubble_sort();
                     s.binary_search();
			         break;
			         
	        case 4 : break;
		}
	}while(ch!=4);
	return 0;
	
}
