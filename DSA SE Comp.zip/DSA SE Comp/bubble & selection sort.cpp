#include<iostream>
using namespace std;

class sort
{
	int n;
	public:
		float per[40];
		void input();
		void bubble();
		void selection();
};

void sort::input()
{
	cout<<"\nEnter the total number of students in class:";
	cin>>n;
	cout<<"\nEnter the percentage of students:";
	for(int i=0;i<n;i++)
	{
		cin>>per[i];
	}
}

void sort::bubble()
{
	float temp;
	for(int i=1;i<n;i++)
	{
		for(int j=0;j<n-1;j++)
		{
			if(per[j]>per[j+1])
			{
				temp=per[j];
				per[j]=per[j+1];
				per[j+1]=temp;
			}
		}
	}
	cout<<"\nSorted percentage order is:";
	for(int i=0;i<n;i++)
	{
		cout<<"\t"<<per[i];
	}
	cout<<"\nThe top five score is:";
	for(int i=n-1;i>=n-5;i--)
	{
		cout<<"\t"<<per[i];
	}
}

void sort::selection()
{
	int k;
	float temp;
	for( int i=0;i<n-1;i++)
	{
		k=i;
		for(int j=i+1;j<n;j++)
		{
			if(per[j]<per[k])
			{
				k=j;
			}
		}
		if(k!=i)
		{
			temp=per[i];
			per[i]=per[k];
			per[k]=temp;
		}
	}
	cout<<"\nSorted percentage order is:";
	for(int i=0;i<n;i++)
	{
		cout<<"\t"<<per[i];
	}
	cout<<"\nThe top five score is:";
	for(int i=n-1;i>=n-5;i--)
	{
		cout<<"\t"<<per[i];
	}
}

int main()
{
	int ch;
	sort s;
	s.input();
	do
	{
		
		cout<<"\nMENU \n 1.BUBBLE SORT \t 2.SELECTION SORT \t 3.EXIT";
		cout<<"\nEnter the sorting technique you want to choose to sort the percentage of students:";
		cin>>ch;
		switch(ch)
		{
			case 1 : s.bubble();
			         break;
			         
			case 2 :  s.selection();
			          break;
			        
			case 3 : break;
		}
	
	}while(ch!=3);
	return 0;
}
