#include<iostream>
using namespace std;

class student
{
  public:
  int marks[10],i,n,min,max,count,avg,sum,count1,count2,count3,count4;
  public:
  	void getdata();
  	void display();
  	void average();
  	void minimum_maximum();
  	void score();
  	void absent();
};

 void student::getdata()
 {
 	cout<<"\nEnter the total number of students";
 	cin>>n;
 	cout<<"\nEnter the marks of the student present for the test and if the student is absent enter -1";
 	for(i=0;i<n;i++)
 	{
 		cin>>marks[i];
 	}
 }
 
 void student::display()
 {
 	cout<<"\nThe marks of the student are:";
 	for(i=0;i<n;i++)
 	{
 		cout<<"\n"<<marks[i];
 	}
 }
 
 void student::minimum_maximum()
 {
 	min=marks[0];
 	for(i=0;i<n;i++)
 	{
 		if(marks[i]<min && marks[i]!=-1)
 		{
 			min=marks[i];
 		}
 	}
 	cout<<"\nThe lowest score of the class is:"<<min;
 	i=0;
 	max=marks[i];
 	for(i=0;i<n;i++)
 	{
 		if(marks[i]>max)
 		{
 			max=marks[i];
 		}
 	}
 	 cout<<"\nThe highest score of the class is:"<<max;
}
 
 void student::average()
 {
 	sum=0;
 	for(i=0;i<n;i++)
 	{
 		if(marks[i]!=-1)
 		{
 			sum=sum+marks[i];
 		}
 	}
 	n=n-count;
 	avg=(sum/n);
 	cout<<"\nThe average score of the class is:"<<avg;
}

void student::absent()
{
	count=0;
	for(i=0;i<n;i++)
	{
		if(marks[i]==-1)
		{
			count++;
		}
	}
	cout<<"\nThe total number of absent student is:"<<count;
} 

void student::score()
{
	count1=0,count2=0,count3=0,count4=0;
	for(i=0;i<n;i++)
  {
	if(marks[i]>60)
	{
		count1++;
	}
	else
	 if(marks[i]>50 && marks[i]<=59)
	  {
	  	count2++;
	  }
	  else
	   if(marks[i]>40 && marks[i]<=49)
	   {
	   	count3++;
	   }
	   else
	    if(marks[i]<=39 && marks [i]>-1)
	    {
	    	count4++;
	    }
 }
  cout<<"\nThe number of students with score above 60 are:"<<count1;
   cout<<"\nThe number of students with score between 50 to 60 are:"<<count2;
    cout<<"\nThe number of students with score between 50 to 40 are:"<<count3;
     cout<<"\nThe number of students with score below 40 are:"<<count4;
}
 int main()
 {
 	student s;
 	s.getdata();
 	s.display();
 	s.minimum_maximum();
 	s.score();
 	s.absent();
 	s.average();
 	return 0;
 }
