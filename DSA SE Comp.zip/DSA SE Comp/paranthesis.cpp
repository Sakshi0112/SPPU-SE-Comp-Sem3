#include<iostream>
using namespace std;

class stack
{
	public:
		char s[25];
		int top;
		bool empty();
		bool full();
		void push(char x);
		char pop();
		stack()
		{
			top=-1;
		}
};
bool stack::empty()
{
	if(top==-1)
	{
	  return 1;
    }
    return 0;
}

bool stack::full()
{
	if(top==24)
	{
		return 1;
	}
	return 0;
}

void stack::push(char x)
{
	if(top==24)
	{
		cout<<"\nStack is full";
	}
	else
	{
		top=top+1;
		s[top]=x;
	}
}

char stack::pop()
{
	if(top==-1)
	{
		cout<<"\nStack is empty";
		return '*';
	}
	else
	{
	  char x=s[top];
	  top=top-1;
	  return x;
    } 
}    

class expression
{
	public:
		char expn[25];
		stack obj;
		void read();
	    void checkexpn();
};

void expression::read()
{
	cout<<"\nEnter the expression:";
	cin>>expn;
	cout<<"\nThe entered expression is:"<<expn;
}

void expression::checkexpn()
{
	char ch;
	int i,flag;
	flag=0;
	for(i=0;expn[i]!='\0';i++)
	{
		if(expn[i]=='(' || expn[i]=='{' || expn[i]=='[')
		{
			obj.push(expn[i]);
		}
		if(expn[i]==')' || expn[i]=='}' || expn[i]==']')
		{
			if(!obj.empty())
			{
		       ch=obj.pop();
		       if(expn[i]==')' &&ch!='(')
		         {
		         	flag=1;
		         	break;
		         }
		      if(expn[i]=='}' && ch!='{')
		       {
		       	flag =1;
		       	break;
		       }
		       if(expn[i]==']' && ch!='[')
		       {
		       	 flag=1;
		       	 break;
		       }
		    }
		}
		
    }
	if(flag==0 && obj.empty())
	{
		cout<<"\nExpression is well paranthesised";
	}
	else
	{
		cout<<"\nExpression is not well paranthesised";
	}
}

int main()
{
	expression e;
	e.read();
	e.checkexpn();
	return 0;
}
