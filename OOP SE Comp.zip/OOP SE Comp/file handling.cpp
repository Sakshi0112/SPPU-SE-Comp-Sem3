#include<fstream>
#include<iostream>
using namespace std;

int main()
{
	char data[100];
	
	ofstream out;
	out.open("myfile.txt");
	
	cout<<"\nWriting to the file"<<endl;
	
	cout<<"\nEnter the name:";
	cin.getline(data,100);
	
	out<<data<<endl;
	
	cout<<"\nEnter the age:";
	cin>>data;
	
	out<<data<<endl;
	
	cout<<"\nEnter the place:";
	cin>>data;
	
	out<<data<<endl;
	
	out.close();
	
	ifstream in;
	in.open("myfile.txt");
	cout<<"\nReading from the file"<<endl;
	in>>data;
    cout<<data<<endl;
    
    in>>data;
    cout<<data<<endl;
    
    in>>data;
    cout<<data<<endl;
    
    in.close();
    
    return 0;
}
