#include<iostream>
#include<cstring>
#include<ctype.h>
using namespace std;

int main()
{
	int age,c,vehicle;
	double income;
	char city[10],city1[10]="Pune",city2[10]="Mumbai",city3[10]="Bangalore",city4[10]="Chennai";
	
	try
	{
		cout<<"\nEnter the age:";
		cin>>age;
		if(age<18 || age>55)
		{
			throw(1);
		} 
		else
		{
			cout<<"\nThe age is:"<<age;
		}
		
		cout<<"\nEnter the income:";
		cin>>income;
		if(income<50000 || income>100000)
		{
			throw(2);
		}
		else
		{
			cout<<"\nThe income entered is:"<<income;
		}
		
		cout<<"\nEnter the city:";
		cin>>city;
		if(strcmp(city1,city)!=0 && strcmp(city2,city)!=0 && strcmp(city3,city)!=0 &&strcmp(city4,city)!=0)
		{
			throw(3);
		}
		else
		{
			cout<<"\nThe city is:"<<city;
		}
		
		cout<<"\nEnter 4 for a four-wheeler and 2 for a two-wheeler:";
		cin>>vehicle;
		if(vehicle!=4)
		{
			throw(4);
		}
		else
		{
			cout<<"\nThe vehicle entered is a"<<vehicle<<"-wheeler";
		}
	}
	
	catch(int c)
	{
		switch(c)
		{
			case 1 :cout<<"\nException caught!\n Age entered should be in between 18 to 55";
			        break;
			        
			case 2 :cout<<"\nException caught!\n Income entered should be in between 50000 to 100000";
			        break;
			        
			case 3 :cout<<"\nException caught!\n City entered should be from amongst the following:Pune,Mumbai,Bangalore,Chennai";
			        break;
			        
			case 4 :cout<<"\nException caught!\n The vehicle entry must be 4 for a four-wheeler";
			        break;
		}
	}
	return 0;
}
