#include<iostream>
using namespace std;

class cpp_array
{
	int a[10],b[10],n,i,j;
	public:
		void getdata(int x[10]);
		void print(int x[10]);
		void sort(int x[10]);
		void range(int x[10]);
		void exchange(int x[10],int y[10]);
		int size(int x[10]);
};

void cpp_array::getdata(int x[10])
{
	cout<<"\nEnter the total size of the array:";
	cin>>n;
	cout<<"\nEnter the elements of the array:";
	for(i=0;i<n;i++)
	{
		cin>>x[i];
	}
}

void cpp_array::print(int x[10])
{
	cout<<"\nThe elements of the array are:";
	for(i=0;i<n;i++)
	{
		cout<<"\t"<<x[i];
	}
}

 void cpp_array::sort(int x[10])
 {
 	int temp;
 	for(i=1;i<n;i++)
 	{
 		for(j=0;j<n-1;j++)
 		{
 			if(x[j]>x[j+1])
 			{
 				temp=x[j+1];
 				x[j+1]=x[j];
 				x[j]=temp;
 			}
 		}
 	}
 	cout<<"\nThe sorted array is:";
 	for(i=0;i<n;i++)
 	{
 		cout<<"\t"<<x[i];
 	}
 }
 
  void cpp_array::range(int x[10])
  {
  	cout<<"\nThe range of the array is from:"<<x[0]<<" to "<<x[n-1];
  }
  
  void cpp_array::exchange(int x[10],int y[10])
  {
  	for(i=0;i<n;i++)
  	{
  		y[i]=x[i];
  	}
  	cout<<"\nThe exchanged array is:";
  	for(i=0;i<n;i++)
  	{
  		cout<<"\nb["<<i<<"]="<<y[i];
  	}
  }
  
 int cpp_array::size(int x[10])
 {
 	return n;
 }
 
 int main()
 {
 	int a[10],b[10],p;
 	cpp_array c1;
 	c1.getdata(a);
 	c1.print(a);
 	c1.sort(a);
 	c1.range(a);
 	c1.getdata(b);
 	c1.print(b);
 	c1.sort(b);
 	c1.range(b);
 	c1.exchange(a,b);
 	p=c1.size(a);
 	cout<<"\nThe size of the array is:"<<p;
 	return 0;
 }
