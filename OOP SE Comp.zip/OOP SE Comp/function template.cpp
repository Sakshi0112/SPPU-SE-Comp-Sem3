#include<iostream>
using namespace std;

template <class T>

void sort()
{
	int i,j,k;
	T temp;
	T n[5];
	cout<<"\nEnter the five numbers:";
	for(i=0;i<5;i++)
	{
		cin>>n[i];
	}
	for(i=0;i<4;i++)
	{
		k=i;
		for(j=i+1;j<5;j++)
		{
			if(n[j]<n[k])
			{
				k=j;
			}
		}
		if(k!=i)
		{
			temp=n[i];
			n[i]=n[k];
			n[k]=temp;
		}
	}
	cout<<"\nSorted array is:";
	for(i=0;i<5;i++)
	{
		cout<<"\t"<<n[i];
	}
}

int main()
{
	int ch;
	char ans;
	do
	{
		cout<<"\n1.INTEGER SORT\t 2.FLOAT SORT";
		cout<<"\nEnter the choice:";
		cin>>ch;
		switch(ch)
		{
			case 1 :sort<int>();
			        break;
			        
			case 2 :sort<float>();
			        break;
			        
			case 3 :cout<<"\nINVALID choice";
			        break;
		}
		cout<<"\nDo you want to continue (Y/N)?:";
		cin>>ans;
	}while(ans=='Y' || ans=='y');
	return 0;
}
