#include<iostream>
#include<cstring>
using namespace std;

class personal_info
{
	protected:
		int age,dob;
		string nm;
	public:
		void getdata1();
};

class academic_info
{
	protected:
		int marks,yr_of_passing;
		float percentile;
		string class_obtained;
	public:void getdata2();
};

class professional_info
{
	protected:
		int yr_of_exp;
    	string nm_of_proj,nm_of_cmpy,proj_details;
	public:
		void getdata3();
};

class biodata:public personal_info,public professional_info,public academic_info
{
	public:
		void display();
};

void personal_info::getdata1()
{
	cout<<"\nEnter the name:";
	cin>>nm;
	cout<<"\nEnter the date of birth in the following format DDMMYYYY:";
	cin>>dob;
	cout<<"\nEnter the age:";
	cin>>age;
}

void academic_info::getdata2()
{
	cout<<"\nEnter the year of passing:";
	cin>>yr_of_passing;
	cout<<"\nEnter the marks scored:";
	cin>>marks;
	cout<<"\nEnter the percentile:";
	cin>>percentile;
	cout<<"\nEnter the class obtained:";
	cin>>class_obtained;
}

void professional_info::getdata3()
{
	cout<<"\nEnter the years of experience:";
	cin>>yr_of_exp;
	cout<<"\nEnter the name of the company:";
	cin>>nm_of_cmpy;
	cout<<"\nEnter the name of the project:";
	cin>>nm_of_proj;
	cout<<"\nEnter the project details:";
	cin>>proj_details;
}

void biodata::display()
{
	cout<<"\n--------------------PERSONAL INFO--------------------";
	cout<<"\nNAME is:"<<nm;
	cout<<"\nDATE OF BIRTH is:"<<dob;
	cout<<"\nAGE is:"<<age;
	cout<<"\n---------------------ACADEMIC INFO--------------------";
	cout<<"\nYEAR OF PASSING:"<<yr_of_passing;
	cout<<"\nMARKS:"<<marks;
	cout<<"\nPERCENTILE:"<<percentile;
	cout<<"\nCLASS OBTAINED:"<<class_obtained;
	cout<<"\n------------------PROFESSIONAL INFO-------------------";
	cout<<"\nYEARS OF EXPERIENCE:"<<yr_of_exp;
	cout<<"\nNAME OF COMPANY:"<<nm_of_cmpy;
	cout<<"\nNAME OF PROJECT:"<<nm_of_proj;
	cout<<"\nPROJECT DETAILES:"<<proj_details;
}
	
int main()
{
	biodata b;
	b.getdata1();
	b.getdata2();
	b.getdata3();
	b.display();
	return 0;
}	
