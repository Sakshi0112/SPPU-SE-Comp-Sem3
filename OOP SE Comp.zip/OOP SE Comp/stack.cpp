#include<iostream>
#include<cstring>
#include<list>
using namespace std;

class stack
{
	public:
		int a;
		list<int>s;
		list<int>::iterator itr;
		
		void push()
		{
			cout<<"\nEnter the element you want to push on the stack:";
			cin>>a;
			s.push_back(a);
		}
		
		void display_stack()
		{
			cout<<"\nThe elements in the stack are:";
			for(itr=s.begin();itr!=s.end();itr++)
			{
				cout<<"\t"<<*itr;
			}
		}
		
		void pop()
		{
			itr=s.end();
			itr--;
			s.pop_back();
			cout<<"\nThe element popped out of the stack is:"<<*itr;
		}
};

int main()
{
	stack s;
	int ch;
	char ans;
	do
	{
		cout<<"\n1.INSERT ELEMENT\t 2.DELETE ELEMENT\t 3.DISPLAY THE ELEMENTS IN THE STACK";
		cout<<"\nEnter the choice of operation you want to perform:";
		cin>>ch;
		switch(ch)
		{
			case 1 :s.push();
			        break;
			        
			case 2 :s.pop();
			        break;
			        
			case 3 :s.display_stack();
			        break;
		}
		cout<<"\nDo you want want to perform any other operation? (Y/N) :";
		cin>>ans;
	}while(ans=='Y' || ans=='y');
	return 0;
}
