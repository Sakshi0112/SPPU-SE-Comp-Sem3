#include<iostream>
using namespace std;

class calculator
{
	float result,num1,num2;
	char op;
	public:
		void getdata();
		void calculate();
};

 void calculator::getdata()
 {
 	cout<<"\nEnter the first number, operator and the second number:";
 	cin>>num1>>op>>num2;
 }
 
 void calculator::calculate()
 {
 	switch(op)
 	{
 		case '+' : result=num1+num2;
 		           cout<<"\nThe result of addition is:"<<result;
 		           break;
 		           
 	    case '-' : result=num1-num2;
 	               cout<<"\nThe result of subtraction is:"<<result;
 	               break;
 	               
 	    case '*' : result=num1*num2;
 	               cout<<"\nThe result of multiplication is:"<<result;
 	               break;
 	               
 	    case '/' : if(num2==0)
 	               {
 	               	cout<<"Error! Invalid input";
 	               }
 	               else
 	               {
 	               	result=num1/num2;
 	               	cout<<"\nThe result of division is:"<<result;
 	               }
 	               break;
 	}
 }
 
 int main()
 {
 	calculator c;
 	char ag;
 	x:c.getdata();
 	  c.calculate();
 	cout<<"\nDo you want to perform any other operation y/n:";
 	cin>>ag;
 	if(ag=='Y' || ag=='y')
 	{
 		goto x;
 	}
 	return 0;
 }
