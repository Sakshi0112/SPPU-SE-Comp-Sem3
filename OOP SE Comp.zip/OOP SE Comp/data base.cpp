#include<iostream>
#include<cstring>
#include<iomanip>
using namespace std;

class data_base
{
	char name[20],dob[15],blood_grp[10],no[10];
	float wt,ht;
	int ins;
	public:
		static int stdno;
		
		static void count()
		{
			cout<<"\nNo. of objects created:"<<stdno;
		}
		
		data_base()
		{
			strcpy(name,"NAME");
			strcpy(dob,"DOB");
			strcpy(blood_grp,"BG");
		    wt=ht=0;
			ins=0;
			strcpy(no,"NO");
		    ++stdno;
		}
		
		data_base(data_base *ob)
		{
			strcpy(name,ob->name);
			strcpy(dob,ob->dob);
			strcpy(blood_grp,ob->blood_grp);
		    wt=ob->wt;
			ht=ob->ht;
			ins=ob->ins;
			strcpy(no,ob->no);
		}
		
		void getdata()
		{
			cout<<"\nEnter:name,date of birth, blood group,contact number,weight,height,insaurance policy number:";
			cin>>name>>dob>>blood_grp>>no>>wt>>ht>>ins;
		}
		
		friend class db;
		
		~data_base()
		{
			cout<<"\n"<<this->name<<"(Object) is destroyed";
	    }
};

int data_base::stdno=0;

class db
{
	public:
		void display(data_base d)
		{
			cout<<"\n"<<setw(10)<<d.name<<setw(15)<<d.dob<<setw(10)<<d.blood_grp<<setw(15)<<d.no<<setw(5)<<d.wt<<setw(5)<<d.ht<<setw(10)<<d.ins;
		}
};
 
int main()
{
	int i,n;
	data_base d1;
	data_base *ptr[5];
	db d;
	cout<<"\nDefault values";
	d.display(d1);
	d1.getdata();
	d.display(d1);
	data_base d2(&d1);
	cout<<"\nUse of copy constructor\n";
	d.display(d2);
	cout<<"\nHow many objects you want to create?:";
	cin>>n;
	for(i=0;i<n;i++)
	{
		ptr[i]=new data_base();
		ptr[i]->getdata();
	}
	data_base::count();
	for(i=0;i<n;i++)
	{
		d.display(*ptr[i]);
	}	
    for(i=0;i<n;i++)
	{
		delete(ptr[i]);
	}
	cout<<"\nObject is deleted!";
	return 0;
}
