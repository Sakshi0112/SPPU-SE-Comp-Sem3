#include<iostream>
#include<cstring>
#include<list>
using namespace std;

class queue
{
	public:
		int a;
		list<int>s;
		list<int>::iterator itr;
		
		void push()
		{
			cout<<"\nEnter the element you want to insert in the queue:";
			cin>>a;
			s.push_back(a);
		}
		
		void display_queue()
		{
			cout<<"\nThe elements in the queue are:";
			for(itr=s.begin();itr!=s.end();itr++)
			{
				cout<<"\t"<<*itr;
			}
		}
		
		void pop()
		{
			itr=s.begin();
			s.pop_front();
			cout<<"\nThe element deleted from the queue is:"<<*itr;
		}
};

int main()
{
	queue q;
	int ch;
	char ans;
	do
	{
		cout<<"\n1.INSERT ELEMENT\t 2.DELETE ELEMENT\t 3.DISPLAYING THE ELEMENTS IN THE QUEUE";
		cout<<"\nEnter the choice of operation you want to perform:";
		cin>>ch;
		switch(ch)
		{
			case 1 :q.push();
			        break;
			        
			case 2 :q.pop();
			        break;
			        
			case 3 :q.display_queue();
			        break;
		}
		cout<<"\nDo you want to perform any other operation? (Y/N):";
		cin>>ans;
	}while(ans=='Y' || ans=='y');
	return 0;
}
