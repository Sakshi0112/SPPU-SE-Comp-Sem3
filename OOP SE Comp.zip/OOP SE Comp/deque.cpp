#include<iostream>
#include<cstring>
#include<list>
using namespace std;

class deque
{
	public:
		int a;
	    list<int>s;
	    list<int>::iterator itr;
	
	void push_front()
	{
		cout<<"\nEnter the elements you want to insert in the queue:";
		cin>>a;
		s.push_front(a);
	}
	
	void push_back()
	{
		cout<<"\nEnter the elements you want to insert in the queue:";
		cin>>a;
		s.push_back(a);
	}
	
	void pop_front()
	{
		itr=s.begin();
		s.pop_front();
		cout<<"\nThe element deleted from the queue is:"<<*itr;
	}

    void pop_back()
	{
		itr=s.end();
		itr--;
		s.pop_back();
		cout<<"\nThe element deleted from the queue is:"<<*itr;
	}
	
	void display_deque()
	{
		cout<<"\nThe elements of the queue are:";
		for(itr=s.begin();itr!=s.end();itr++)
		{
			cout<<"\t"<<*itr;
		}
	}
};

int main()
{
	deque d;
	int ch;
	char ans;
   do
   {
	cout<<"\n1.INSERT FRONT\t 2.INSERT REAR\t 3.DELETE FRONT\t 4.DELETE REAR\t 5.DISPLAY THE ELEMENTS OF THE DEQUE";
	cout<<"\nEnter the choice of operation you want to perform:";
	cin>>ch;
	switch(ch)
	{
		case 1:d.push_front();
		       break;
		       
		case 2:d.push_back();
		       break;
		       
		case 3:d.pop_front();
		       break;
		       
		case 4:d.pop_back();
		       break;
		       
		case 5:d.display_deque();
		       break;
	}
	cout<<"\nDo you want to perform any other operation? (Y/N):";
	cin>>ans;
  }while(ans=='Y' || ans=='y');
  return 0;
}

