#include<iostream>
using namespace std;

class complex
{
	float real,img;
	public:
		complex()
		{
			real=0.0;
			img=0.0;
		}
		complex operator +(complex c2);
		complex operator *(complex c2);
		complex operator -(complex c2);
		complex operator /(complex c2);
		friend istream& operator>>(istream &in,complex &c);
		friend ostream& operator<<(ostream &out,complex &c);
};

 complex complex::operator +(complex c2)
 {
 	complex c;
 	c.real=real+c2.real;
 	c.img=img+c2.img;
 	return c;
 }
 
 istream &operator>>(istream &in,complex &c)
 {
 	in>>c.real>>c.img;
 }
 
 ostream &operator<<(ostream &out,complex &c)
 {
 	out<<c.real<<"+i"<<c.img;
 }
 
 complex complex::operator *(complex c2)
 {
 	complex c;
 	c.real=(real*c2.real);
 	c.img=(img*c2.img);
 	return c;
 }
 
 complex complex::operator -(complex c2)
 {
 	complex c;
 	c.real=real-c2.real;
 	c.img=img-c2.img;
 	return c;
 } 
 
 complex complex::operator /(complex c2) 
 {
 	complex c;
 	c.real=((real*c2.real)+(img*c2.img))/((c2.real*c2.real)+(c2.img*c2.img));
 	c.img=((img*c2.real)-(real*c2.img))/((c2.real*c2.real)+(c2.img*c2.img));
 	return c;
 }
 
 int main()
 {
 	complex c1,c2,c3;
 	int ch;
 	char ans;
 	cout<<"\nEnter first complex no:";
 	cin>>c1;
 	cout<<"\nEnter second complex no:";
 	cin>>c2;
 	cout<<"\n-----------Solution-------------";
 	cout<<"\nFirst complex no.:"<<c1;
 	cout<<"\nSecond complex no.:"<<c2;
 	do
 	{
 		cout<<"\n1.ADDITION\t 2.SUBTRACTION\t 3.MULTIPLICATION\t 4.DIVISION";
 		cout<<"\nEnter the choice:";
 		cin>>ch;
 		switch(ch)
 		{
 		   case 1 :	c3=c1+c2;
 	                cout<<"\nAddition is:"<<c3;
 	                break;
 	                
 	       case 2 :c3=c1-c2;
 	               cout<<"\nSubtraction is:"<<c3;
 	               break;
 	               
 	       case 3 :c3=c1*c2;
 	               cout<<"\nMultiplication is:"<<c3;
 	               break;
 	            
 	            
 	        case 4 :c3=c1/c2;
 	                cout<<"\nDivision is:"<<c3;
 	                break;
 		}
 		cout<<"\nDo you want to perform any other operation? (Y/N):";
 		cin>>ans;
 	}while(ans=='Y' || ans=='y');
 	return 0;
 }
 
 
